<div class="sidebar">
    <div class="menu">
        <h4 class="ms-2 fw-normal"><i class="lni lni-grid-alt me-2 ms-1 mt-1"></i>CLASSKOTO</h4>
        <ul class="list-unstyled mt-4">
            <li><a href="./index.php" class="text-decoration-none"><i class="lni lni-home me-3"></i>Dashboard</a></li>
            <li><a href="./attendance.php" class="text-decoration-none"><i class="lni lni-pencil-alt me-3"></i>Attendance</i></a></li>
            <li><a href="./schedules.php" class="text-decoration-none"><i class="lni lni-control-panel me-3"></i></i>Schedules</a></li>
            <li><a href="./subjects.php" class="text-decoration-none"><i class="lni lni-laptop me-3"></i>Subjects</a></li>
        </ul>
    </div>
    <button class="logout d-flex align-items-center justify-content-center p-2" data-hystmodal="#logout"><i class="lni lni-exit me-1"></i>Logout</button>
</div>