const li = document.querySelectorAll('li')


// console.log(li)