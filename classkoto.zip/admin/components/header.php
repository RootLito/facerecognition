<div class="header">
    <div class="user">
        <button><i class="bi bi-bell-fill"></i></button>
        <div class="prof"><i class="bi bi-person-fill"></i></div>
        <p class="m-0">Chunkz Dev</p>
    </div>
</div>
