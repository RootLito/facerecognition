<div class="sidebar">
    
    <div class="menu">
        <h4 class="ms-2 fw-normal"><i class="lni lni-grid-alt me-2 ms-1 mt-1"></i>CLASSKOTO</h4>
        <ul class="list-unstyled mt-4">
            <li><a href="./index.php" class="text-decoration-none"><i class="lni lni-home me-3"></i>Dashboard</a></li>
            <li><a href="./as.php" class="text-decoration-none"><i class="lni lni-pencil-alt me-3"></i>Attendance Schedule</i></a></li>
            <li><a href="./tp.php" class="text-decoration-none"><i class="lni lni-user me-3"></i>Teacher Profile</a></li>
            <li><a href="./subjects.php" class="text-decoration-none"><i class="lni lni-laptop me-3"></i>Subjects</a></li>
        </ul>
    </div>
    <button class="logout d-flex align-items-center justify-content-center p-2"><i class="lni lni-exit me-1"></i>Logout</button>
</div>